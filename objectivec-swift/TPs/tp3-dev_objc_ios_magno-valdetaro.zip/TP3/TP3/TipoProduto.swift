//
//  Produtos.swift
//  TP3
//
//  Created by Magno Valdetaro on 5/21/16.
//  Copyright © 2016 infnet. All rights reserved.
//

import Foundation

enum TipoProduto : String {
    case Chaveiro = "Chaveiro"
    case Estatua = "Estátua"
    case Ima = "Imã"
}