//
//  Jogador.swift
//  assessment_q1
//
//  Created by Magno Valdetaro on 6/4/16.
//  Copyright © 2016 infnet. All rights reserved.
//

import Foundation

class Jogador {
    var nome:String?
    var email:String?
    var dataDeNascimento: NSDate?
    var telefone:String?
}