//
//  Produto.swift
//  TP2_questao2
//
//  Created by Magno Valdetaro on 4/24/16.
//  Copyright © 2016 infnet. All rights reserved.
//

import Foundation

class Produto {
    var valorDeCusto:Double?
    var codigoDoProduto:Int?
}
