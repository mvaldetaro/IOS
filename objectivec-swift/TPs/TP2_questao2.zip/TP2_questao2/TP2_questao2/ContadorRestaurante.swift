//
//  ContadorRestaurante.swift
//  TP2_questao2
//
//  Created by Magno Valdetaro on 4/30/16.
//  Copyright © 2016 infnet. All rights reserved.
//

import Foundation

protocol ContadorRestaurante {
    func calcularEImprimirGastos(saidas:Cozinha) -> String
}
