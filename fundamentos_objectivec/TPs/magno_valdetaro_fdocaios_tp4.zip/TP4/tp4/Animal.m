//
//  Animal.m
//  tp4
//
//  Created by Magno Valdetaro on 3/19/16.
//  Copyright © 2016 infnet. All rights reserved.
//

#import "Animal.h"

@implementation Animal

@end
