//
//  Animal.h
//  tp4
//
//  Created by Magno Valdetaro on 3/19/16.
//  Copyright © 2016 infnet. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Animal : NSObject

    @property (strong) NSString *genero;

@end
