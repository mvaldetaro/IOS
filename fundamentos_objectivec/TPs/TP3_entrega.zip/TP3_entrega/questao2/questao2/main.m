//
//  main.m
//  questao2
//
//  Created by Magno Valdetaro on 3/5/16.
//  Copyright © 2016 Magno Valdetaro. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}
