//
//  AppDelegate.h
//  tp5-projeto-bloco
//
//  Created by Magno Valdetaro on 3/26/16.
//  Copyright © 2016 infnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

