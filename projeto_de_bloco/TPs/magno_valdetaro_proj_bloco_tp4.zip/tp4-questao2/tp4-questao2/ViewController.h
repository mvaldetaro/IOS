//
//  ViewController.h
//  tp4-questao2
//
//  Created by Magno Valdetaro on 3/20/16.
//  Copyright © 2016 infnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *textField1;

@property (strong, nonatomic) IBOutlet UITextField *textField2;


- (IBAction)btnEnviar:(id)sender;

@end

