//
//  SegundaViewController.h
//  tp4-questao2
//
//  Created by Magno Valdetaro on 3/20/16.
//  Copyright © 2016 infnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SegundaViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *labelField;
@property (strong, nonatomic) IBOutlet UILabel *labelField2;
@property (strong, nonatomic) NSString *textFieldsContent;
@property (strong, nonatomic) NSString *textFieldsContentPart2;

@end
