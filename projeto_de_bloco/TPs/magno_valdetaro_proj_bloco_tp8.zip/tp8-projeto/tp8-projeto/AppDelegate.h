//
//  AppDelegate.h
//  tp8-projeto
//
//  Created by Magno Valdetaro on 5/2/16.
//  Copyright © 2016 infnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

