//
//  AppDelegate.h
//  calculadora
//
//  Created by Magno Valdetaro on 3/12/16.
//  Copyright © 2016 infnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

